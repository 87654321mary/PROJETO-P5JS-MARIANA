let carros = [];
let animais = [];
let nuvens = [];
let pessoas = [];
let passaros = [];

function setup() {
  createCanvas(800, 400);
  
  // Criando carros com velocidade mais lenta
  for (let i = 0; i < 3; i++) {
    carros.push(new Carro(450 + i * 120, random(300, 350), random(0.5, 1.5)));
  }
  
  // Criando animais com velocidade mais lenta
  for (let i = 0; i < 3; i++) {
    animais.push(new Animal(100 + i * 120, random(300, 350), random(0.3, 0.7)));
  }
  
  // Criando nuvens
  for (let i = 0; i < 5; i++) {
    nuvens.push(new Nuvem(random(width), random(50, 150)));
  }
  
  // Criando pessoas
  for (let i = 0; i < 4; i++) {
    pessoas.push(new Pessoa(width / 2 + random(50, 350), random(300, 380)));
  }
  
  // Criando pássaros
  for (let i = 0; i < 5; i++) {
    passaros.push(new Passaro(random(0, width / 2), random(50, 150)));
  }
}

function draw() {
  background(135, 206, 235);
  
  desenhaSol();
  desenhaCampo();
  desenhaCidade();
  
  // Nuvens
  for (let nuvem of nuvens) {
    nuvem.mover();
    nuvem.mostrar();
  }
  
  // Pássaros
  for (let passaro of passaros) {
    passaro.mover();
    passaro.mostrar();
  }
  
  // Animais
  for (let animal of animais) {
    animal.mover();
    animal.mostrar();
  }
  
  // Carros
  for (let carro of carros) {
    carro.mover();
    carro.mostrar();
  }
  
  // Pessoas
  for (let pessoa of pessoas) {
    pessoa.mover();
    pessoa.mostrar();
  }
}

function desenhaSol() {
  fill(255, 204, 0);
  noStroke();
  ellipse(700, 80, 80, 80);
}

function desenhaCampo() {
  noStroke();
  fill(34, 139, 34);
  rect(0, height / 2, width / 2, height / 2);
  
  // Montanhas
  fill(85, 107, 47);
  triangle(150, 200, 50, 400, 250, 400);
  triangle(300, 220, 200, 400, 400, 400);
  
  // Árvores
  for (let i = 0; i < 3; i++) {
    desenhaArvore(50 + i * 100, 250);
  }
}

function desenhaCidade() {
  noStroke();
  fill(50);
  rect(width / 2, height / 2, width / 2, height / 2);
  
  // Prédios parados
  for (let i = 0; i < 5; i++) {
    let x = width / 2 + i * 60;
    let h = 150;  // altura fixa para todos os prédios
    fill(100);
    rect(x, height / 2 - h, 50, h);
  }
  
  // Faixa de pedestres
  for (let i = 0; i < 10; i++) {
    fill(255);
    rect(width / 2 + i * 30, height - 50, 20, 5);
  }
}

function desenhaArvore(x, y) {
  fill(139, 69, 19);
  rect(x, y, 20, 50);
  fill(34, 139, 34);
  ellipse(x + 10, y - 10, 50, 50);
}

// Classes

class Carro {
  constructor(x, y, velocidade) {
    this.x = x;
    this.y = y;
    this.velocidade = velocidade;
  }
  
  mover() {
    this.x += this.velocidade;
    if (this.x > width) {
      this.x = width / 2;
    }
  }
  
  mostrar() {
    fill(255, 0, 0);
    rect(this.x, this.y, 50, 20);
    fill(0);
    ellipse(this.x + 10, this.y + 20, 10, 10);
    ellipse(this.x + 40, this.y + 20, 10, 10);
  }
}

class Animal {
  constructor(x, y, velocidade) {
    this.x = x;
    this.y = y;
    this.velocidade = velocidade;
    this.direcao = random([-1, 1]);
  }
  
  mover() {
    this.x += this.direcao * this.velocidade;
    if (this.x < 0 || this.x > width / 2) {
      this.direcao *= -1;
    }
  }
  
  mostrar() {
    fill(160, 82, 45);
    ellipse(this.x, this.y, 30, 20);
    ellipse(this.x - 10, this.y - 10, 15, 15);
  }
}

class Nuvem {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  
  mover() {
    this.x += 0.5;
    if (this.x > width) {
      this.x = -50;
    }
  }
  
  mostrar() {
    fill(255);
    noStroke();
    ellipse(this.x, this.y, 50, 30);
    ellipse(this.x + 20, this.y + 10, 50, 30);
    ellipse(this.x - 20, this.y + 10, 50, 30);
  }
}

class Pessoa {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.direcao = random([-1, 1]);
  }
  
  mover() {
    this.x += this.direcao * 0.5; // velocidade reduzida
    if (this.x < width / 2 || this.x > width) {
      this.direcao *= -1;
    }
  }
  
  mostrar() {
    fill(0);
    ellipse(this.x, this.y - 10, 10, 10);
    rect(this.x - 5, this.y, 10, 20);
  }
}

class Passaro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  
  mover() {
    this.x += 1;
    this.y += sin(frameCount * 0.05) * 0.5;
    if (this.x > width / 2) {
      this.x = -20;
    }
  }
  
  mostrar() {
    fill(0);
    triangle(this.x, this.y, this.x + 10, this.y - 5, this.x + 10, this.y + 5);
  }
}
function desenhaCidade() {
  noStroke();
  fill(50);
  rect(width / 2, height / 2, width / 2, height / 2);
  
  // Prédios parados
  for (let i = 0; i < 5; i++) {
    let x = width / 2 + i * 60;
    let h = 150;  
    fill(100);
    rect(x, height / 2 - h, 50, h);
  }
  
  // Faixa de pedestres - agora mais acima
  for (let i = 0; i < 12; i++) {
    fill(255);
    rect(width / 2 + i * 20, height / 2 + 80, 15, 20);
  }
  
  // Semáforo
  desenhaSemaforo(width / 2 + 20, height / 2 + 50);
  
  // Placas
  desenhaPlaca(width / 2 + 200, height / 2 + 100, "PARE");
  desenhaPlaca(width / 2 + 300, height / 2 + 130, "ATENÇÃO");
}

function desenhaSemaforo(x, y) {
  fill(0);
  rect(x, y, 20, 60, 5);
  
  fill(255, 0, 0);
  ellipse(x + 10, y + 10, 15, 15);
  
  fill(255, 255, 0);
  ellipse(x + 10, y + 30, 15, 15);
  
  fill(0, 255, 0);
  ellipse(x + 10, y + 50, 15, 15);
}

function desenhaPlaca(x, y, texto) {
  fill(255, 255, 0);
  rect(x, y, 40, 20, 5);
  
  fill(0);
  textSize(10);
  textAlign(CENTER, CENTER);
  text(texto, x + 20, y + 10);
}
function desenhaPedestresNaFaixa() {
  for (let i = 0; i < 3; i++) {
    let x = width / 2 + 250 - frameCount * 0.5 + i * 30;  // andam devagar para a esquerda
    let y = height / 2 + 90;  // na altura da faixa
    desenhaPessoa(x, y);
  }
}
function desenhaCampo() {
  noStroke();
  fill(34, 139, 34);
  rect(0, height / 2, width / 2, height / 2);
  
  // Montanhas
  fill(85, 107, 47);
  triangle(150, 200, 50, 400, 250, 400);
  triangle(300, 220, 200, 400, 400, 400);
  
  // Mais árvores
  for (let i = 0; i < 6; i++) {  // aumentei de 3 para 6
    desenhaArvore(50 + i * 60, 250 + random(-20, 20));
  }
}
