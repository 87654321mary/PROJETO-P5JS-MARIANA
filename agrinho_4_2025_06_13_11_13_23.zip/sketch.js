let modo = "campo"; // estado inicial
let botao;

function setup() {
  createCanvas(800, 400);

  // Criar botão
  botao = createButton("Mudar para Cidade");
  botao.position(20, 20);
  botao.mousePressed(trocarModo);
}

function draw() {
  background(220);

  if (modo === "campo") {
    drawSky(0, 0, width, height, color(135, 206, 250));
    drawGrass(0, height - 100, width, 100);
    drawTrees(width);
    drawHouse(); // agora com posição e escala melhores
  } else {
    drawSky(0, 0, width, height, color(180));
    drawBuildings();
    drawRoad();
    drawCars();
  }
}

function trocarModo() {
  if (modo === "campo") {
    modo = "cidade";
    botao.html("Mudar para Campo");
  } else {
    modo = "campo";
    botao.html("Mudar para Cidade");
  }
}

// Funções para o campo
function drawSky(x, y, w, h, c) {
  noStroke();
  fill(c);
  rect(x, y, w, h);
}

function drawGrass(x, y, w, h) {
  fill(34, 139, 34);
  rect(x, y, w, h);
}

function drawTrees(widthLimit) {
  for (let i = 50; i < widthLimit; i += 120) {
    fill(101, 67, 33); // tronco
    rect(i, 250, 20, 60);
    fill(0, 128, 0); // copa
    ellipse(i + 10, 240, 60, 60);
  }
}

function drawHouse() {
  let baseX = 500;
  let baseY = 200;

  // Corpo da casa
  fill(255, 228, 196);
  rect(baseX, baseY, 120, 100);

  // Telhado
  fill(150, 75, 0);
  triangle(baseX, baseY, baseX + 60, baseY - 50, baseX + 120, baseY);

  // Porta
  fill(100, 50, 0);
  rect(baseX + 50, baseY + 50, 20, 50);

  // Janelas
  fill(173, 216, 230);
  rect(baseX + 20, baseY + 20, 20, 20);
  rect(baseX + 80, baseY + 20, 20, 20);
}

// Funções para a cidade
function drawBuildings() {
  for (let i = 0; i < 5; i++) {
    fill(80);
    rect(100 + i * 120, 150 - i * 10, 80, 250 + i * 10);

    // janelas
    fill(255, 255, 100);
    for (let j = 0; j < 5; j++) {
      for (let k = 0; k < 3; k++) {
        rect(110 + i * 120 + k * 20, 160 + j * 40, 10, 10);
      }
    }
  }
}

function drawRoad() {
  fill(50);
  rect(0, height - 60, width, 60);

  stroke(255);
  strokeWeight(2);
  for (let i = 0; i < width; i += 40) {
    line(i + 10, height - 30, i + 30, height - 30);
  }
  noStroke();
}

function drawCars() {
  fill(255, 0, 0);
  rect(300, height - 50, 40, 20);
  fill(0);
  ellipse(305, height - 30, 10, 10);
  ellipse(335, height - 30, 10, 10);
}
function drawCows() {
  drawCow(150, 280);
  drawCow(300, 300);
  drawCow(650, 290);
}

function drawCow(x, y) {
  // Corpo
  fill(255);
  rect(x, y, 50, 30, 10);

  // Manchas
  fill(0);
  ellipse(x + 10, y + 10, 10, 10);
  ellipse(x + 35, y + 20, 8, 8);

  // Cabeça
  fill(255);
  rect(x - 20, y + 5, 20, 20, 5);

  // Olhos
  fill(0);
  ellipse(x - 10, y + 10, 4, 4);

  // Chifres
  stroke(0);
  line(x - 18, y + 5, x - 22, y - 5);
  line(x - 4, y + 5, x, y - 5);
  noStroke();

  // Pernas
  fill(0);
  rect(x + 5, y + 30, 5, 10);
  rect(x + 35, y + 30, 5, 10);
}

